

define("work_modules/main", ["work_modules/gallery"], function(){
    //check if entrance in gallery controller is done
    console.log('loaded');
});